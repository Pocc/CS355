use jacobsro;

select * from user;

describe user_rating;

CREATE OR REPLACE VIEW user_rating_view AS
SELECT U.uid, U.username, M.movie_id, M.title, R.rating 
FROM user U, movie M, user_rating R 
WHERE U.uid = R.uid AND M.movie_id = R.movie_id;

select * from user_rating_view;

select Distinct username U from user UNION
select distinct title from movie M;

SELECT distinct username, title from user_rating_view;

SELECT * from user_rating;

SELECT distinct uid, username, movie_id, title
FROM user, mfovie;
 

DROP PROCEDURE IF EXISTS GetUsernameAndTitle;
DELIMITER //

CREATE PROCEDURE GetUsernameAndTitle( _username VARCHAR(256), _title VARCHAR(256))
BEGIN
	SELECT
		t1.username, t2.title
	FROM
		(SELECT uid, username, @user_row := @user_row + 1 AS rownum FROM user, (SELECT @user_row := 0) r1 ORDER BY uid) AS t1
		 LEFT JOIN
		(SELECT movie_id, title, @movie_row := @movie_row + 1 AS rownum FROM movie, (SELECT @movie_row := 0) r2 ORDER BY movie_id) AS t2
		ON t1.rownum = t2.rownum;
END //
DELIMITER ;   

CREATE PROCEDURE insertNewRating( _username VARCHAR(256), _title VARCHAR(256), _rating INT)
BEGIN
	INSERT INTO user_rating (uid, movie_id, rating) 
		SELECT uid, movie_id, rating 
        FROM user U JOIN user_rating UR ON U.uid = UR.uid
			JOIN movie M on M.movie_id = UR.movie_id
		WHERE _username = U.username AND _title = M.title
   END //
DELIMITER ;   

INSERT INTO user_rating (uid, movie_id, rating) SELECT 2, 3, 7 FROM user U, movie M, user_rating UR 
WHERE U.uid = UR.uid AND M.movie_id = UR.movie_id AND username IN (SELECT username FROM user) AND title IN (SELECT title FROM movie);