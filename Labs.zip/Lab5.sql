USE jacobsro;

# Lab 5, CS 355, Instructor : Micahel Haderman
# Author : Ross Jacobs
# 2016-02-22
SET SQL_SAFE_UPDATES = 0; # Otherwise #15 and onward won't compile

SELECT first_name, last_name FROM student ORDER BY last_name, first_name; #1)
SELECT first_name, last_name FROM student ORDER BY last_name DESC, first_name ASC; #2)
SELECT department_name FROM department ORDER BY department_name DESC; #3)
SELECT course_name FROM course ORDER BY course_name DESC; #4)
SELECT COUNT(*) AS number_of_students FROM student; #5)
SELECT COUNT(*) AS number_of_departments FROM department; #6)
SELECT COUNT(*) AS number_of_courses FROM course; #7)
SELECT major, COUNT(*) FROM student GROUP BY major; #8)
ALTER TABLE student ADD COLUMN minor varchar(50) DEFAULT 'CS' NOT NULL; #9)
SELECT minor, COUNT(*) FROM student GROUP BY minor; #10)
SELECT department_id, COUNT(*) FROM course GROUP BY department_id; #11)
SELECT department_name, COUNT(course_id) as number_of_courses FROM department d
	LEFT JOIN course c ON c.department_id = d.department_id
	GROUP BY department_name; #12) #13)
    
SELECT course_name, COUNT(*) as number_of_students FROM course c
	JOIN section s ON c.course_id = s.course_id
	JOIN grade_report g ON g.section_id = s.section_id
	JOIN student t ON t.student_id = g.student_id
	GROUP BY course_name; #14)
    
ALTER TABLE grade_report MODIFY grade_value FLOAT;
UPDATE grade_report SET grade_value = CASE grade_letter  
	WHEN 'A+' THEN 4.0 
	WHEN 'A' THEN 4.0 
    WHEN 'B+' THEN 3.3
    WHEN 'B' THEN 3.0
    WHEN 'C' THEN 2.0
    WHEN 'D' THEN 1.0
    WHEN 'F' THEN 0.0
	ELSE NULL END; #15)
SELECT * FROM grade_report;

    
SELECT c.course_id, grade_letter, AVG(grade_value) as average_grade FROM grade_report g
	JOIN section s ON g.section_id = s.section_id
	JOIN course c ON c.course_id = s.course_id
	JOIN student t ON t.student_id = g.student_id
	GROUP BY c.course_id; #16)

SELECT student_number, AVG(grade_value) as GPA FROM grade_report g
	JOIN section s ON g.section_id = s.section_id
	JOIN course c ON c.course_id = s.course_id
	JOIN student t ON t.student_id = g.student_id
	GROUP BY t.student_number; 
INSERT INTO grade_report (student_id, section_id, grade_letter) 
values (1,2,'A'),
(2,3,'C'),
(3,2,'D'),
(3,1,'B');
SELECT * FROM grade_report; #17)

SELECT student_number, SUM(grade_value)/COUNT(t.student_id) as GPA FROM grade_report g
	JOIN section s ON g.section_id = s.section_id
	JOIN course c ON c.course_id = s.course_id
	JOIN student t ON t.student_id = g.student_id
	GROUP BY t.student_number; #18)

SELECT student_number,first_name,last_name, AVG(grade_value) as GPA FROM grade_report g
	JOIN section s ON g.section_id = s.section_id
	JOIN course c ON c.course_id = s.course_id
	JOIN student t ON t.student_id = g.student_id
	WHERE last_name='Smith'; #19)
    
SELECT last_name,first_name, AVG(grade_value) as GPA FROM grade_report g
	JOIN section s ON g.section_id = s.section_id
	JOIN course c ON c.course_id = s.course_id
	JOIN student t ON t.student_id = g.student_id
	GROUP BY last_name HAVING GPA > 3.0; #20)
    
SELECT department_name, 
	MIN(grade_value) as MinGPA, 
	AVG(grade_value) as AvgGPA,
	MAX(grade_value) as MaxGPA FROM department d
	JOIN course c ON d.department_id = c.department_id
    JOIN section s ON c.course_id = s.course_id
    JOIN grade_report g ON g.section_id = s.section_id
	GROUP BY d.department_name; #21)

CREATE OR REPLACE VIEW DepartmentGPAView AS
	SELECT department_name, 
		MIN(grade_value) as MinGPA, 
		AVG(grade_value) as AvgGPA,
		MAX(grade_value) as MaxGPA FROM department d
		JOIN course c ON d.department_id = c.department_id
		JOIN section s ON c.course_id = s.course_id
		JOIN grade_report g ON g.section_id = s.section_id
		GROUP BY d.department_name; 
SELECT * FROM DepartmentGPAView; #22)

SELECT department_name, AvgGPA FROM DepartmentGPAView WHERE AvgGPA > 2.0; #23)

CREATE OR REPLACE VIEW StudentGPA AS
	SELECT AVG(grade_value) as AvgGPA, s.* FROM student s 
		JOIN grade_report g ON g.student_id = s.student_id		
		GROUP BY s.student_id; 
SELECT * FROM StudentGPA; #24)
