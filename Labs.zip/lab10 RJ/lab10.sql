SET SQL_SAFE_UPDATES=0;
USE jacobsro;

CREATE TABLE states (state_id INT PRIMARY KEY AUTO_INCREMENT, state_name VARCHAR(255));
INSERT INTO states (state_name) VALUES ("California"), ("Oregon"), ("Nevada");

ALTER TABLE user ADD COLUMN state_id INT;
ALTER TABLE user ADD FOREIGN KEY (state_id) REFERENCES states (state_id);

select * from genre;