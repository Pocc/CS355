var express = require('express');
var router = express.Router();
var genreDal = require('../model/genre_dal');

router.get('/', function (req, res) {
    genreDal.GetByID(req.query.genre_id, function (err, result) {
            if (err) throw err;
            res.render('genre/genre_insert_form.ejs', {rs: result, genre_id: req.query.genre_id});
        }
    );
});

router.get('/new', function(req, res) {
    res.render('genre/genre_insert_form');
});

router.post('/genre_insert', function(req, res){
    genreDal.Insert(req.query.genre_name, function(err, result){
        var response = {};
        if(err) {
            response.message = err.message;
        }
        else {
            response.message = 'Success!';
        }
        res.json(response);
    });
});


/* My former stuff
router.get('/new', function(req, res) {
    genreDal.GetAll( function(err, result){
        if(err) {
            res.send("Error: " + err);
        }
        else {
            res.render('genre/genre_insert_form.ejs', {genre: result});
        }
    });

});

router.post('/genre_insert', function(req, res) {
    console.log(req.body);
    genreDal.Insert(req.body.genre_name,
        function(err){
            if(err){
                res.send('Fail!<br />' + err);
            } else {
                res.redirect('/movie/all');
            }
        } );
}); */

module.exports = router;