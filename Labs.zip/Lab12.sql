SET SQL_SAFE_UPDATES=0;
USE jacobsro;

SELECT COUNT(applicationID) FROM Applied_To WHERE company_name='Moneymakers Incorporated';
SELECT COUNT(username) FROM School WHERE school_name = 'University of Californizona';


CREATE TABLE User
(
  lastname INT NOT NULL,
  firstname INT NOT NULL,
  password INT NOT NULL,
  username INT NOT NULL,
  PRIMARY KEY (username)
);

CREATE TABLE Account
(
  Email INT NOT NULL,
  username INT NOT NULL,
  FOREIGN KEY (username) REFERENCES User(username)
);

CREATE TABLE Resume
(
  resume_name INT NOT NULL,
  username INT NOT NULL,
  PRIMARY KEY (resume_name, username),
  FOREIGN KEY (username) REFERENCES User(username)
);

CREATE TABLE School
(
  Street_Address INT NOT NULL,
  City INT NOT NULL,
  State INT NOT NULL,
  Zip_Code INT NOT NULL,
  school_name INT NOT NULL,
  Year_Graduated INT NOT NULL,
  Year_Started INT NOT NULL,
  GPA INT NOT NULL,
  resume_name INT NOT NULL,
  username INT NOT NULL,
  PRIMARY KEY (school_name),
  FOREIGN KEY (resume_name, username) REFERENCES Resume(resume_name, username),
  UNIQUE (Street_Address),
  UNIQUE (City),
  UNIQUE (State),
  UNIQUE (Zip_Code)
);

CREATE TABLE Skill
(
  skill_name INT NOT NULL,
  skill_description INT NOT NULL,
  resume_name INT NOT NULL,
  username INT NOT NULL,
  PRIMARY KEY (skill_name),
  FOREIGN KEY (resume_name, username) REFERENCES Resume(resume_name, username)
);

CREATE TABLE Company
(
  company_name INT NOT NULL,
  PRIMARY KEY (company_name)
);

CREATE TABLE Company_Address
(
  Street_Address INT NOT NULL,
  City INT NOT NULL,
  Zip_Code INT NOT NULL,
  State INT NOT NULL,
  company_name INT NOT NULL,
  FOREIGN KEY (company_name) REFERENCES Company(company_name),
  UNIQUE (Street_Address),
  UNIQUE (City),
  UNIQUE (Zip_Code),
  UNIQUE (State)
);

CREATE TABLE Job
(
  job_description INT NOT NULL,
  job_title INT NOT NULL,
  starting_month INT NOT NULL,
  starting_year INT NOT NULL,
  ending_month INT NOT NULL,
  ending_year INT NOT NULL,
  company_name INT NOT NULL,
  PRIMARY KEY (job_title, company_name),
  FOREIGN KEY (company_name) REFERENCES Company(company_name)
);

CREATE TABLE Job_on_Resume
(
  job_title INT NOT NULL,
  company_name INT NOT NULL,
  resume_name INT NOT NULL,
  username INT NOT NULL,
  FOREIGN KEY (job_title, company_name) REFERENCES Job(job_title, company_name),
  FOREIGN KEY (resume_name, username) REFERENCES Resume(resume_name, username)
);

CREATE TABLE Applied_To
(
  Date_Applied INT NOT NULL,
  Got_Job_Offer INT NOT NULL,
  applicationID INT NOT NULL,
  resume_name INT NOT NULL,
  username INT NOT NULL,
  company_name INT NOT NULL,
  FOREIGN KEY (resume_name, username) REFERENCES Resume(resume_name, username),
  FOREIGN KEY (company_name) REFERENCES Company(company_name),
  UNIQUE (applicationID)
);
