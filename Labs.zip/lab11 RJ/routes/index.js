var express = require('express');
var router = express.Router();
var accountDAL = require('../model/account_dal');

/* GET home page. */
router.get('/', function(req, res, next) {
  var data = {
    title : 'Express'
  }
  if(req.session.account === undefined) {
    res.render('index', data);
  }
  else {
    data.firstname = req.session.account.firstname;
    res.render('index', data);
  }
});

router.get('/authenticate', function(req, res) {
  accountDAL.GetByEmail(req.query.email, req.query.password, function (err, account) {
    var response = {};
    if (err) {
      console.log("authenticate_error");
      //res.send(err);
      response.message = err.message;
      res.json(response);
    }
    else if (account == null) {
      //res.send("User not found.");
      response.message = 'Email not found.';
      res.json(response);
    }
    else {
      req.session.account = account;
      /*if(req.session.originalUrl = '/login') {
        req.session.originalUrl = '/'; //don't send user back to login, instead forward them to the homepage.
      }
      console.log(req.session.originalUrl);
      res.redirect(req.session.originalUrl);
      //res.send(account);*/
      response.message = "Success!";
      res.json(response);
    }

  });
});

router.get('/login', function(req, res, next) {
  if(req.session.account) {
    res.redirect('/'); //user already logged in so send them to the homepage.
  }
  else {
    res.render('authentication/login.ejs');
  }
});

router.get('/logout', function(req, res) {
  req.session.destroy( function(err) {
    res.render('authentication/logout.ejs');
  });
});

router.get('/signup', function(req, res, next) {
  if(req.session.account) {
    res.redirect('/'); //user already logged in so send them to the homepage.
  }
  else {
    res.render('authentication/signup.ejs');
  }
});

router.get('/new_user', function(req, res) {
  console.log(req.query.email);
  console.log('in new user');
  accountDAL.Insert(req.query.username, req.query.firstname, req.query.lastname, req.query.email, req.query.password, req.query.state_id,
      function(err){
        var response = {};
        if(err){
          res.send('Fail!<br />' + err);
        } else {
          //.send('Success!')
          // user will be shown list of updated users
          response.message = "Success!";
          res.json(response);
        }
      } );
});

module.exports = router;
