var express = require('express');
var router = express.Router();
var ratingDal = require('../model/rating_dal');

/*
router.get('/', function (req, res) {
    ratingDal.GetByID(req.query.rating_id, function (err, result) {
        console.log("in ratings route");
            if (err) throw err;
            res.render('rating/rating_insert_form.ejs', {rs: result, rating_id: req.query.rating_id});
        }
    );
});*/



router.get('/', function (req, res,next) {
    movieDal.GetAll(req.query.rating, function (err, result) {
            if (err) throw err;
            res.render('rating/rating_insert_form.ejs', {rs: result, rating: req.query.rating});
        }
    );
});


router.get('/new', function(req, res) {
    ratingDal.GetByMovieID(function (err, result) {
        if (err) throw err;
        var data = {
            title : 'Express'
        };
        data.firstname = req.session.account.firstname;
        data.rating_id = req.query.rating_id;
        data.username = req.session.account.username;
        data.rs = result;
        res.render('rating/rating_insert_form.ejs',  data);
    });
});

/*
router.get('/new', function(req, res) {
    ratingDal.GetUsernameAndTitle(req.query.username, req.query.title,
        function (err, result) {
            var response = {};
            if (err) {
                console.log("rating_error");
                //res.send(err);
                response.message = err.message;
                res.json(response);
            }
            else {
                response.message = "Success!";
                res.json(response);
            }

        });
});*/

router.post('/rating_insert', function(req, res){
    ratingDal.Insert(req.query.username, req.query.title, req.query.rating, function(err, result){
        var response = {};
        if(err) {
            response.message = err.message;
        }
        else {
            response.message = 'Success!';
        }
        res.json(response);
    });
});


/* My former stuff
router.get('/new', function(req, res) {
    ratingDal.GetAll( function(err, result){
        if(err) {
            res.send("Error: " + err);
        }
        else {
            res.render('rating/rating_insert_form.ejs', {rating: result});
        }
    });

});

router.post('/rating_insert', function(req, res) {
    console.log(req.body);
    ratingDal.Insert(req.body.rating_name,
        function(err){
            if(err){
                res.send('Fail!<br />' + err);
            } else {
                res.redirect('/movie/all');
            }
        } );
}); */

module.exports = router;