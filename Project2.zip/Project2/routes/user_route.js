/**
 * Created by ross on 4/12/2016.
 */
var express = require('express');
var router = express.Router();
var userDal = require('../model/user_dal');




router.get('/', function (req, res) {
    userDal.GetByID(req.query.uid, function (err, result) {
            if (err) throw err;
        var data = {
            rs : result,
            uid : req.query.uid,
        };
            res.render('user/display_user_info.ejs', data);
        }
    );
});

router.get('/all', function(req, res) {
    userDal.GetAll(function (err, result) {
            if (err) throw err;
            var data = {rs : result, firstname : req.session.account.firstname};
            res.render('user/display_all_users.ejs', data);
        }
    );
});

// Added for Lab 10

router.get('/new', function(req, res) {
    userDal.GetAll( function(err, result){
        if(err) {
            res.send("Error: " + err);
        }
        else {
            var data = {
                user : result,
                firstname : req.session.account.firstname,
                rs : result
            }
            res.render('user/user_insert_form.ejs', data);
        }
    });

});

// Added for Lab 10

router.post('/insert_user', function(req, res) {
    console.log(req.body);
    userDal.Insert(req.body.username, req.body.firstname, req.body.lastname,
        req.body.email, req.body.password, req.body.state_id,
        function(err){
            if(err){
                res.send('Fail!<br />' + err);
            } else {
                //.send('Success!')
                // user will be shown list of updated users
                res.redirect('/user/all');
            }
        } );
});

// Added for Lab 10

router.get('/edit', function(req, res){
    console.log('/edit uid:' + req.query.uid);

    userDal.GetByID(req.query.uid, function(err, user_result){
        if(err) {
            console.log(err);
            res.send('error: ' + err);
        }
        else {
            console.log(user_result);
            var data = {
                rs : user_result,
                users : user_result,
                message : req.query.message,
                firstname : req.session.account.firstname
            };
            userDal.GetAll(function(err, user_result){
                console.log(user_result);
                res.render('user/user_edit_form', data);
            });
        }
    });
});

// Added for Lab 10

router.post('/update_user', function(req,res){
    console.log(req.body);
    // first update the user
    userDal.Update(req.body.uid, req.body.username, req.firstname, req.body.lastname,
        req.body.email, req.body.password, req.body.state_id,
        function(err){
            var message;
            if(err) {
                console.log(err);
                message = 'error: ' + err.message;
            }
            else {
                // Success popup
            }
            // next update the users
            var data = {
                firstname : req.session.account.firstname
            };
            userDal.GetByID(req.body.uid, function(err, uid){
                userDal.GetAll(function(err, uid) {
                    console.log(uid);
                    res.render('/user/all', data);
                    //res.redirect('/user/edit?user_id=' + req.body.user_id + '&message=' + message);
                    //res.render('user/user_edit_form', {rs: user_info, users: user_result});
                });
            });

        });
});

// Added for Lab 10

router.get('/delete', function(req, res){
    console.log(req.query);
    console.log("In /delete route");
    userDal.GetByID(req.query.uid, function(err, result) {
        if(err){
            res.send("Error: " + err);
        }
        else if(result.length != 0) {
            userDal.DeleteUserRatingByUID(req.query.uid, function (err) {});
            userDal.DeleteUserByUID(req.query.uid, function (err) {
                //var data = {firstname : req.session.account.firstname, rs : result};
                res.redirect('/user/all');
            });
        }
        else {
            res.send('User does not exist in the database.');
        }
    });
});

module.exports = router;
