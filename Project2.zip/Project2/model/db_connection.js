/**
 * Created by ross on 4/12/2016.
 */
exports.config = {
    user: 'jacobsro',
    password: '004430444',
    host: 'blue.cs.sonoma.edu',
    database: 'jacobsro'
};

