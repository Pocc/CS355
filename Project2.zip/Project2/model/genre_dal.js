var mysql   = require('mysql');
var db  = require('./db_connection.js');

/* DATABASE CONFIGURATION */
var connection = mysql.createConnection(db.config);

exports.GetAll = function(callback){
    var qry = "SELECT * from genre;"
    connection.query(qry, function(err, result){
        callback(err, result);
    });
}

exports.Insert = function(genre_name, callback) {
    var qry = "INSERT INTO genre (genre_name) VALUES (?)";
    connection.query(qry, genre_name, function(err, result){
        callback(err, result);
    });
}

/*
exports.Insert = function(genre_name, callback) {
    console.log(genre_name);
    var dynamic_query = 'INSERT INTO genre (genre_name) VALUES ('+ '\'' + genre_name + '\'' + ');';
    console.log(dynamic_query);

    // connection.query(query, is where the SQL string we built above is actually sent to the MySQL server to be run
    connection.query(dynamic_query,
        function (err, result) {
            if(err) {
                console.log(err);
                callback(true);
                return;
            }
            callback(false, result);
        }
    );
}*/